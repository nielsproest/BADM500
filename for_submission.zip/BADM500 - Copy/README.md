Download http://imada.sdu.dk/~roettger/teaching/resources/bachelor_project/all_data.zip

Put BRCA_clinicalMatrix in BRCA and run BRCA.py
PAM50_labels-RNA-Seq_1148.csv, PAM50_labels-RNA-Seq_737.csv, PAM50_labels-RNA-Seq_534.csv, PAM50_labels-Meth450_679.csv, PAM50_labels-Meth450_513.csv, and PAM50_labels-Meth450_378.csv in PAM50 and run filtering.py
Put HiSeqV2 in HiSeq and run gather.py
Run Kasperstuff/filterZeros.py and Kasperstuff/filter2.py and rename masterNew3.csv to masterNew.csv in Kasperstuff
Most files should now be ready to run

For evaluation of classifiers with selected genes look into the Fix folder
For gene visualization of average values look into Gene folder
For multiple gene visualization on line plot lookl into Gene_Visualize folder
For early gradient boost work look into GradientBoost
For outlier detection look into HiSeq
For gene and zero filtering look into Kasperstuff
For early decision tree work look into Tree
For some unfinished unsupervised work and pearson correlation look into Unsup
For zero visualization look into Zeros
For general experimenting look into Martin and Martinsfiler

For RFE work look into the .ipynb files (you need Jupyter notebook, theres a visual studio code extension for it)
For the final RFE work look into the .ipynb files in Martin

Sometimes Martin likes to rename the master file, just edit it back to ../Kasperstuff/masterNew.csv