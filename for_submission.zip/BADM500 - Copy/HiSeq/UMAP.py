import pandas as pd
import plotly.express as px
from sklearn.decomposition import PCA
import json
import umap

df = pd.read_csv("../Kasperstuff/masterNew.csv",sep=";")

types = df.columns.values
genes = types[1:-1] #Remove SampleID and PAM50_Label
X = df[genes]

components = umap.UMAP(random_state=999, n_neighbors=30, min_dist=.25).fit_transform(X)

samples = list(df["sampleID"])
fig = px.scatter(components, x=0, y=1, color=df["PAM50_Label"], hover_name=samples)



fig.show()
